//! Importing the logics 

//Named 

import {addition , even}  from  './math.js' 
// import {even} from './math.js'
import {double , triple} from './math.js'
import { multiply , division as div } from './math.js';

//Default 

import calculation from './math.js';  


console.log(addition(1,2)); //3
console.log(even);//2
console.log(double(5)); //10 
console.log(triple(3)); //9
console.log(multiply(4,5)); //20 
console.log(div(10,5)); //2
console.log(calculation(10,5,5));//10






