//! Exporting the logics 

//? Two types of exports : 
//1. Named Export 
//2. Default Export 

//! 1. NAMED EXPORT 

//! 1st way of named export 

export function addition(a,b){
     return a+b
}  

export let even = 2 

//! 2nd way of named export 

function double(x){
    return 2*x
}

function triple(y){
    return 3*y
}

export {double , triple}

//! 3rd way of named export 

function multiplication(x,y){
    return x*y
}

function division(a,b){
    return a/b
}

export {multiplication as multiply , division} 


//! 2] DEFAULT EXPORT 
// You can have only one default export from one file. 
// You should not use curly braces. 
// Syntax :  export default functionalityName 

function calculation(a,b,c){
    return a+b-c
}

export default calculation 

