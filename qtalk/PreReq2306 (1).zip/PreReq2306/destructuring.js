//!Destructuring 

//?Destructuring of arrays  
// Destructuring of an array is an easier way to access the elements ,
// without using the index values. 

let students = ["Krishna", "Nikhil", "Ayushi", "Rajani", "Nivetha", "Geetha", "Roshani"]

console.log(students[2]);  //Ayushi

let [s1 , s2 , s3 , s4 , s5 , s6 , s7] = students //destructuring of array 

console.log(s2);  //Nikhil

let [firstStudent ,,,,,, lastStudent] = students //destructuring of array
console.log(lastStudent); //Roshani


//example 

let products = ["mobile", "laptop", ["refrigerator" , "air fryer"]]

let [pd1 , pd2 , pd3] = products   //!destructuring of array
console.log(pd3); //['refrigerator', 'air fryer']

let [pd31 , pd32] = pd3  //destructuring of array
console.log(pd32); //air fryer 

let [pro1 , pro2 , [pro3 , pro4]] = products //!destructuring of array 
console.log(pro3); //refrigerator

//example 

let children = ["Tina", "Mina", ["Tapu", "Goli"], "Sonu"]  

//? Destructuring of objects 
// Destructuring of object is an easier way to access the values of properties ,
// with the help of keynames.

let course = {
    name : "Reactjs", 
    prereq : "Webtech", 
    duration : "30 days"
}

console.log(course.prereq); //Webtech  

let {name , prereq , duration} = course  //!destructuring of object 

console.log(prereq);     

//example 

let details = {
    fname : "Rohit", 
    lname : "Roy",
    address : {
        city : "Delhi", 
        street : "Some street", 
        houseno : 15
    }
}

console.log(details.address.city);  //Delhi

let {fname , lname , address : {city , street , houseno}} = details  //!destructuring of object 

console.log(city);
console.log(houseno);

//example 

let player = {
    batsman : "Virat",
    dob : "5th Nov",
    records : {
        fifties : 73,
        hundreds : 50,
        iplteam :{
            team :"RCB",
            trophies : 2
        }
    }
}

let {batsman , dob , records : {fifties , hundreds , iplteam : {team , trophies}}} = player

console.log(team); //RCB  


//! REST PARAMETER : It is used for packing of values . 
// Syntax :  ...varname 

let fooditems = ["Poori", "CholeBhature" , "Burger", "Biryani", "Dalkhichdi" , "Samosa"]

let [food1 , food2 , ...packedfood ] = fooditems  //! rest parameter 

console.log(packedfood); //['Burger', 'Biryani', 'Dalkhichdi', 'Samosa']  

function add(...number){ //! rest parameter 

  console.log(number); //[1, 2, 3, 4, 5]

  let addition = 0
  for(const element of number){
       console.log(element);
       addition = addition + element  // 15 = 10 + 5
  }
  
   console.log(addition); //15
    
}

add(1,2,3,4,5) 

//! SPREAD OPERATOR : It is used for unpacking of values .
// Syntax : ...varname 

console.log(...packedfood); //! spread operator 

//concat

let batch1 = ["Khushi", "Reena", "Parth"] 

let batch2 = ["Sandeep", "Sudhir", "Priya"] 

let newbatch = [...batch1 , ...batch2 ]  //! spread operator 

console.log(newbatch);  

//copy

let array1 = [10,20,30] 

let newarray = [ ...array1 ]  //! spread operator 
console.log(newarray); //[10, 20, 30]

newarray.push(40,50) 
console.log(newarray); // [10, 20, 30, 40, 50] 

console.log(array1); // [10, 20, 30]





